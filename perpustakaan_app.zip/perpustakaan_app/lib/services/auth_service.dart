import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const String _userKey = 'user_data';

  // Database user dummy (hardcoded)
  static final List<Map<String, dynamic>> _users = [
    {
      'id': 1,
      'nama': 'Petugas Perpus',
      'email': 'petugas@test.com',
      'password': 'password',
      'role': 'petugas',
      'anggota': null,
    },
    {
      'id': 2,
      'nama': 'Sasa Siswa',
      'email': 'sasa@test.com',
      'password': 'password',
      'role': 'anggota',
      'anggota': {
        'id': 1,
        'nis': '12345',
        'kelas': 'XII RPL 1',
      },
    },
  ];

  Future<Map<String, dynamic>> login(String email, String password) async {
    // Simulasi delay jaringan
    await Future.delayed(const Duration(milliseconds: 800));

    final user = _users.firstWhere(
      (u) => u['email'] == email && u['password'] == password,
      orElse: () => {},
    );

    if (user.isEmpty) {
      return {
        'success': false,
        'message': 'Email atau password salah',
      };
    }

    // Simpan sesi
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_userKey, user['email']);

    // Hapus password dari response
    final userData = Map<String, dynamic>.from(user)..remove('password');

    return {'success': true, 'user': userData};
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }

  Future<Map<String, dynamic>?> getSavedUser() async {
    final prefs = await SharedPreferences.getInstance();
    final email = prefs.getString(_userKey);
    if (email == null) return null;

    final user = _users.firstWhere(
      (u) => u['email'] == email,
      orElse: () => {},
    );
    if (user.isEmpty) return null;

    return Map<String, dynamic>.from(user)..remove('password');
  }
}