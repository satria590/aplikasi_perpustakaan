import '../models/buku_model.dart';

class BukuService {
  // Data dummy di memori
  static final List<BukuModel> _bukuList = [
    BukuModel(id: 1, judul: 'Laskar Pelangi', pengarang: 'Andrea Hirata', penerbit: 'Bentang', kategori: 'Novel', stok: 5, rak: 'A1'),
    BukuModel(id: 2, judul: 'Bumi Manusia', pengarang: 'Pramoedya', penerbit: 'Hasta Mitra', kategori: 'Novel', stok: 3, rak: 'A2'),
    BukuModel(id: 3, judul: 'Pemrograman Flutter', pengarang: 'Budi', penerbit: 'Informatika', kategori: 'Teknologi', stok: 4, rak: 'B1'),
    BukuModel(id: 4, judul: 'Algoritma & Pemrograman', pengarang: 'Rinaldi', penerbit: 'Andi', kategori: 'Teknologi', stok: 6, rak: 'B2'),
    BukuModel(id: 5, judul: 'Filosofi Teras', pengarang: 'Henry Manampiring', penerbit: 'Kompas', kategori: 'Filsafat', stok: 2, rak: 'C1'),
  ];

  int _nextId = 6;

  // Ambil semua buku
  Future<List<BukuModel>> getAll({String? search, String? kategori}) async {
    await Future.delayed(const Duration(milliseconds: 300));

    var hasil = List<BukuModel>.from(_bukuList);

    if (search != null && search.isNotEmpty) {
      final key = search.toLowerCase();
      hasil = hasil.where((b) =>
        b.judul.toLowerCase().contains(key) ||
        b.pengarang.toLowerCase().contains(key) ||
        b.kategori.toLowerCase().contains(key)
      ).toList();
    }

    if (kategori != null && kategori.isNotEmpty) {
      hasil = hasil.where((b) => b.kategori == kategori).toList();
    }

    return hasil;
  }

  // Tambah buku
  Future<BukuModel> tambah(BukuModel buku) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final baru = BukuModel(
      id: _nextId++,
      judul: buku.judul,
      pengarang: buku.pengarang,
      penerbit: buku.penerbit,
      kategori: buku.kategori,
      stok: buku.stok,
      rak: buku.rak,
    );
    _bukuList.add(baru);
    return baru;
  }

  // Update buku
  Future<void> update(BukuModel buku) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final idx = _bukuList.indexWhere((b) => b.id == buku.id);
    if (idx != -1) _bukuList[idx] = buku;
  }

  // Hapus buku
  Future<void> hapus(int id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    _bukuList.removeWhere((b) => b.id == id);
  }

  // Ambil daftar kategori unik
  List<String> getKategoriList() {
    return _bukuList.map((b) => b.kategori).toSet().toList()..sort();
  }
}