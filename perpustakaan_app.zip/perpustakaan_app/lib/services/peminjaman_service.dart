import '../models/peminjaman_model.dart';
import '../models/buku_model.dart';

class PeminjamanService {
  // Data peminjaman dummy (di memori)
  static final List<Map<String, dynamic>> _data = [];

  int _nextId = 1;

  // Ambil semua peminjaman milik user tertentu
  Future<List<PeminjamanModel>> getByAnggota(int anggotaId) async {
    await Future.delayed(const Duration(milliseconds: 300));

    return _data
        .where((p) => p['anggota_id'] == anggotaId)
        .map((p) => PeminjamanModel(
              id: p['id'],
              anggotaId: p['anggota_id'],
              bukuId: p['buku_id'],
              tanggalPinjam: p['tanggal_pinjam'],
              tanggalKembali: p['tanggal_kembali'],
              status: p['status'],
              denda: p['denda'],
              buku: p['buku'],
            ))
        .toList();
  }

  // Ambil semua peminjaman (untuk petugas)
  Future<List<PeminjamanModel>> getAll() async {
    await Future.delayed(const Duration(milliseconds: 300));

    return _data
        .map((p) => PeminjamanModel(
              id: p['id'],
              anggotaId: p['anggota_id'],
              bukuId: p['buku_id'],
              tanggalPinjam: p['tanggal_pinjam'],
              tanggalKembali: p['tanggal_kembali'],
              status: p['status'],
              denda: p['denda'],
              buku: p['buku'],
            ))
        .toList();
  }

  // Ajukan peminjaman
  Future<PeminjamanModel> ajukan({
    required int anggotaId,
    required BukuModel buku,
    required DateTime tanggalPinjam,
    required DateTime tanggalKembali,
  }) async {
    await Future.delayed(const Duration(milliseconds: 500));

    final item = {
      'id': _nextId++,
      'anggota_id': anggotaId,
      'buku_id': buku.id,
      'tanggal_pinjam': tanggalPinjam,
      'tanggal_kembali': tanggalKembali,
      'status': 'menunggu',
      'denda': 0.0,
      'buku': buku,
    };
    _data.add(item);

    return PeminjamanModel(
      id: item['id'] as int,
      anggotaId: anggotaId,
      bukuId: buku.id,
      tanggalPinjam: tanggalPinjam,
      tanggalKembali: tanggalKembali,
      status: 'menunggu',
      denda: 0,
      buku: buku,
    );
  }

  // Setujui (petugas)
  Future<void> setujui(int id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final idx = _data.indexWhere((p) => p['id'] == id);
    if (idx != -1) _data[idx]['status'] = 'dipinjam';
  }

  // Tolak (petugas)
  Future<void> tolak(int id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final idx = _data.indexWhere((p) => p['id'] == id);
    if (idx != -1) _data[idx]['status'] = 'ditolak';
  }

  // Proses pengembalian (petugas)
  Future<void> kembalikan(int id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final idx = _data.indexWhere((p) => p['id'] == id);
    if (idx == -1) return;

    final now = DateTime.now();
    final batas = _data[idx]['tanggal_kembali'] as DateTime;
    double denda = 0;

    if (now.isAfter(batas)) {
      final hariTerlambat = now.difference(batas).inDays;
      denda = hariTerlambat * 1000.0;
    }

    _data[idx]['status'] = 'dikembalikan';
    _data[idx]['denda'] = denda;
    _data[idx]['tanggal_dikembalikan'] = now;
  }
}