class ApiConfig {
  // Pakai ini kalau run di Chrome / Web
  static const String baseUrl = 'http://localhost:8000/api';

  // Pakai ini kalau run di Android emulator
  // static const String baseUrl = 'http://10.0.2.2:8000/api';

  // Pakai ini kalau run di HP fisik (ganti IP sesuai komputermu)
  // static const String baseUrl = 'http://192.168.1.100:8000/api';
}