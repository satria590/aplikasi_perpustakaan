class UserModel {
  final int id;
  final String nama;
  final String email;
  final String role;
  final AnggotaModel? anggota;

  UserModel({
    required this.id,
    required this.nama,
    required this.email,
    required this.role,
    this.anggota,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'],
      nama: json['nama'],
      email: json['email'],
      role: json['role'],
      anggota: json['anggota'] != null
          ? AnggotaModel.fromJson(json['anggota'])
          : null,
    );
  }

  bool get isPetugas => role == 'petugas';
  bool get isAnggota => role == 'anggota';
}

class AnggotaModel {
  final int id;
  final String nis;
  final String kelas;

  AnggotaModel({required this.id, required this.nis, required this.kelas});

  factory AnggotaModel.fromJson(Map<String, dynamic> json) {
    return AnggotaModel(
      id: json['id'],
      nis: json['nis'],
      kelas: json['kelas'],
    );
  }
}