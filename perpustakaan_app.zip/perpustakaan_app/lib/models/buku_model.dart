class BukuModel {
  final int id;
  final String judul;
  final String pengarang;
  final String penerbit;
  final String kategori;
  final int stok;
  final String? rak;

  BukuModel({
    required this.id,
    required this.judul,
    required this.pengarang,
    required this.penerbit,
    required this.kategori,
    required this.stok,
    this.rak,
  });

  factory BukuModel.fromJson(Map<String, dynamic> json) {
    return BukuModel(
      id: json['id'],
      judul: json['judul'],
      pengarang: json['pengarang'],
      penerbit: json['penerbit'],
      kategori: json['kategori'],
      stok: json['stok'],
      rak: json['rak'],
    );
  }

  bool get tersedia => stok > 0;
}