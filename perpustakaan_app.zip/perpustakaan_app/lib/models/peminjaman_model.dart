import 'package:flutter/material.dart';
import 'buku_model.dart';

class PeminjamanModel {
  final int id;
  final int anggotaId;
  final int bukuId;
  final DateTime tanggalPinjam;
  final DateTime tanggalKembali;
  final String status;
  final double denda;
  final BukuModel? buku;

  PeminjamanModel({
    required this.id,
    required this.anggotaId,
    required this.bukuId,
    required this.tanggalPinjam,
    required this.tanggalKembali,
    required this.status,
    required this.denda,
    this.buku,
  });

  factory PeminjamanModel.fromJson(Map<String, dynamic> json) {
    return PeminjamanModel(
      id: json['id'],
      anggotaId: json['anggota_id'],
      bukuId: json['buku_id'],
      tanggalPinjam: DateTime.parse(json['tanggal_pinjam']),
      tanggalKembali: DateTime.parse(json['tanggal_kembali']),
      status: json['status'],
      denda: double.parse(json['denda'].toString()),
      buku: json['buku'] != null ? BukuModel.fromJson(json['buku']) : null,
    );
  }

  String get statusLabel {
    switch (status) {
      case 'menunggu': return 'Menunggu';
      case 'dipinjam': return 'Dipinjam';
      case 'dikembalikan': return 'Dikembalikan';
      case 'terlambat': return 'Terlambat';
      default: return status;
    }
  }

  Color get statusColor {
    switch (status) {
      case 'menunggu': return Colors.orange;
      case 'dipinjam': return Colors.blue;
      case 'dikembalikan': return Colors.green;
      case 'terlambat': return Colors.red;
      default: return Colors.grey;
    }
  }
}