import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../petugas/dashboard_petugas.dart';
import '../anggota/dashboard_anggota.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();

  Future<void> _login() async {
    final auth = context.read<AuthProvider>();
    final ok = await auth.login(_emailCtrl.text, _passCtrl.text);

    if (!mounted) return;

    if (ok) {
      final user = auth.user!;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => user.isPetugas
              ? const DashboardPetugas()
              : const DashboardAnggota(),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Email atau password salah')),
      );
    }
  }

  // Isi otomatis untuk demo
  void _isiDemo(String email) {
    setState(() {
      _emailCtrl.text = email;
      _passCtrl.text = 'password';
    });
  }

  @override
  Widget build(BuildContext context) {
    final loading = context.watch<AuthProvider>().loading;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 60),
              const Icon(Icons.library_books, size: 100, color: Colors.blue),
              const SizedBox(height: 16),
              const Text('Perpustakaan Digital',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              const Text('Aplikasi Peminjaman Buku',
                  style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 40),

              TextField(
                controller: _emailCtrl,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.email),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _passCtrl,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                ),
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: loading ? null : _login,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                  ),
                  child: loading
                      ? const SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(
                              color: Colors.white, strokeWidth: 2),
                        )
                      : const Text('LOGIN', style: TextStyle(fontSize: 16)),
                ),
              ),

              const SizedBox(height: 30),
              const Divider(),
              const SizedBox(height: 12),
              const Text('Akun Demo (klik untuk isi otomatis)',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),

              Card(
                child: ListTile(
                  leading: const Icon(Icons.admin_panel_settings, color: Colors.orange),
                  title: const Text('Petugas'),
                  subtitle: const Text('petugas@test.com / password'),
                  onTap: () => _isiDemo('petugas@test.com'),
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.school, color: Colors.green),
                  title: const Text('Anggota'),
                  subtitle: const Text('sasa@test.com / password'),
                  onTap: () => _isiDemo('sasa@test.com'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}