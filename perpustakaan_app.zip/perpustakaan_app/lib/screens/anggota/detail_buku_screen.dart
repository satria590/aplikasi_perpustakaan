import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/buku_model.dart';
import '../../providers/auth_provider.dart';
import '../../services/peminjaman_service.dart';

class DetailBukuScreen extends StatefulWidget {
  final BukuModel buku;
  const DetailBukuScreen({super.key, required this.buku});

  @override
  State<DetailBukuScreen> createState() => _DetailBukuScreenState();
}

class _DetailBukuScreenState extends State<DetailBukuScreen> {
  final PeminjamanService _service = PeminjamanService();
  DateTime? _tglPinjam;
  DateTime? _tglKembali;
  bool _loading = false;

  Future<void> _pilihTanggal() async {
    final now = DateTime.now();
    final pinjam = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 30)),
      helpText: 'Pilih Tanggal Pinjam',
    );
    if (pinjam == null) return;

    final kembali = await showDatePicker(
      context: context,
      initialDate: pinjam.add(const Duration(days: 7)),
      firstDate: pinjam.add(const Duration(days: 1)),
      lastDate: pinjam.add(const Duration(days: 30)),
      helpText: 'Pilih Tanggal Kembali',
    );
    if (kembali == null) return;

    setState(() {
      _tglPinjam = pinjam;
      _tglKembali = kembali;
    });
  }

  Future<void> _ajukan() async {
    if (_tglPinjam == null || _tglKembali == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih tanggal pinjam & kembali dulu')),
      );
      return;
    }

    final user = context.read<AuthProvider>().user;
    if (user?.anggota == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data anggota tidak ditemukan')),
      );
      return;
    }

    setState(() => _loading = true);

    try {
      await _service.ajukan(
        anggotaId: user!.anggota!.id,
        buku: widget.buku,
        tanggalPinjam: _tglPinjam!,
        tanggalKembali: _tglKembali!,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pengajuan peminjaman berhasil!'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.pop(context, true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String _formatTanggal(DateTime? d) {
    if (d == null) return 'Belum dipilih';
    return '${d.day}/${d.month}/${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    final buku = widget.buku;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Buku'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Cover
          Center(
            child: Container(
              width: 140,
              height: 200,
              decoration: BoxDecoration(
                color: Colors.blue.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.book, size: 80, color: Colors.blue),
            ),
          ),
          const SizedBox(height: 20),

          // Info buku
          Text(buku.judul,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _infoRow('Pengarang', buku.pengarang),
          _infoRow('Penerbit', buku.penerbit),
          _infoRow('Kategori', buku.kategori),
          _infoRow('Rak', buku.rak ?? '-'),
          _infoRow(
            'Stok',
            '${buku.stok} buku',
            warna: buku.tersedia ? Colors.green : Colors.red,
          ),

          const Divider(height: 40),

          // Pilih tanggal
          const Text('Ajukan Peminjaman',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),

          Card(
            child: ListTile(
              leading: const Icon(Icons.calendar_today, color: Colors.blue),
              title: const Text('Tanggal Pinjam'),
              subtitle: Text(_formatTanggal(_tglPinjam)),
              onTap: _pilihTanggal,
            ),
          ),
          Card(
            child: ListTile(
              leading:
                  const Icon(Icons.event_available, color: Colors.green),
              title: const Text('Tanggal Kembali'),
              subtitle: Text(_formatTanggal(_tglKembali)),
              onTap: _pilihTanggal,
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: (!buku.tersedia || _loading) ? null : _ajukan,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
              ),
              icon: _loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          color: Colors.white, strokeWidth: 2),
                    )
                  : const Icon(Icons.send),
              label: Text(buku.tersedia
                  ? 'Ajukan Peminjaman'
                  : 'Stok Habis'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value, {Color? warna}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(label,
                style: const TextStyle(color: Colors.grey, fontSize: 13)),
          ),
          const Text(': '),
          Expanded(
            child: Text(value,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: warna)),
          ),
        ],
      ),
    );
  }
}