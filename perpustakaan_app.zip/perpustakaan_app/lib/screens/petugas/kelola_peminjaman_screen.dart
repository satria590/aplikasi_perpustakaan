import 'package:flutter/material.dart';
import '../../models/peminjaman_model.dart';
import '../../services/peminjaman_service.dart';

class KelolaPeminjamanScreen extends StatefulWidget {
  const KelolaPeminjamanScreen({super.key});

  @override
  State<KelolaPeminjamanScreen> createState() =>
      _KelolaPeminjamanScreenState();
}

class _KelolaPeminjamanScreenState extends State<KelolaPeminjamanScreen> {
  final PeminjamanService _service = PeminjamanService();
  List<PeminjamanModel> _list = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final data = await _service.getAll();
    if (!mounted) return;
    setState(() {
      _list = data;
      _loading = false;
    });
  }

  String _tgl(DateTime? d) =>
      d == null ? '-' : '${d.day}/${d.month}/${d.year}';

  Future<void> _aksi(String aksi, PeminjamanModel p) async {
    if (aksi == 'setujui') await _service.setujui(p.id);
    if (aksi == 'tolak') await _service.tolak(p.id);
    if (aksi == 'kembali') await _service.kembalikan(p.id);
    _loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kelola Peminjaman'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _list.isEmpty
              ? const Center(child: Text('Belum ada pengajuan'))
              : RefreshIndicator(
                  onRefresh: _loadData,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _list.length,
                    itemBuilder: (context, i) {
                      final p = _list[i];
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      p.buku?.judul ?? 'Buku',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: p.statusColor.withOpacity(0.15),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      p.statusLabel,
                                      style: TextStyle(
                                        color: p.statusColor,
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text(
                                  'Pinjam: ${_tgl(p.tanggalPinjam)}  •  Kembali: ${_tgl(p.tanggalKembali)}',
                                  style: const TextStyle(
                                      fontSize: 12, color: Colors.grey)),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  if (p.status == 'menunggu') ...[
                                    Expanded(
                                      child: ElevatedButton.icon(
                                        onPressed: () =>
                                            _aksi('setujui', p),
                                        icon: const Icon(Icons.check, size: 18),
                                        label: const Text('Setujui'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.green,
                                          foregroundColor: Colors.white,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: ElevatedButton.icon(
                                        onPressed: () => _aksi('tolak', p),
                                        icon: const Icon(Icons.close, size: 18),
                                        label: const Text('Tolak'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.red,
                                          foregroundColor: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                  if (p.status == 'dipinjam')
                                    Expanded(
                                      child: ElevatedButton.icon(
                                        onPressed: () =>
                                            _aksi('kembali', p),
                                        icon: const Icon(Icons.undo, size: 18),
                                        label: const Text('Proses Kembali'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.blue,
                                          foregroundColor: Colors.white,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}