import 'package:flutter/material.dart';
import '../../models/buku_model.dart';
import '../../services/buku_service.dart';

class FormBukuScreen extends StatefulWidget {
  final BukuModel? buku;
  const FormBukuScreen({super.key, this.buku});

  @override
  State<FormBukuScreen> createState() => _FormBukuScreenState();
}

class _FormBukuScreenState extends State<FormBukuScreen> {
  final _formKey = GlobalKey<FormState>();
  final _service = BukuService();

  late TextEditingController _judul;
  late TextEditingController _pengarang;
  late TextEditingController _penerbit;
  late TextEditingController _kategori;
  late TextEditingController _stok;
  late TextEditingController _rak;

  bool _loading = false;
  bool get _isEdit => widget.buku != null;

  @override
  void initState() {
    super.initState();
    _judul = TextEditingController(text: widget.buku?.judul ?? '');
    _pengarang = TextEditingController(text: widget.buku?.pengarang ?? '');
    _penerbit = TextEditingController(text: widget.buku?.penerbit ?? '');
    _kategori = TextEditingController(text: widget.buku?.kategori ?? '');
    _stok = TextEditingController(text: widget.buku?.stok.toString() ?? '');
    _rak = TextEditingController(text: widget.buku?.rak ?? '');
  }

  Future<void> _simpan() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);
    final buku = BukuModel(
      id: widget.buku?.id ?? 0,
      judul: _judul.text,
      pengarang: _pengarang.text,
      penerbit: _penerbit.text,
      kategori: _kategori.text,
      stok: int.tryParse(_stok.text) ?? 0,
      rak: _rak.text.isEmpty ? null : _rak.text,
    );

    if (_isEdit) {
      await _service.update(buku);
    } else {
      await _service.tambah(buku);
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isEdit ? 'Buku diupdate' : 'Buku ditambahkan'),
        backgroundColor: Colors.green,
      ),
    );
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEdit ? 'Edit Buku' : 'Tambah Buku'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _field('Judul', _judul),
            _field('Pengarang', _pengarang),
            _field('Penerbit', _penerbit),
            _field('Kategori', _kategori),
            _field('Stok', _stok, keyboard: TextInputType.number),
            _field('Rak (opsional)', _rak, required: false),
            const SizedBox(height: 20),
            SizedBox(
              height: 50,
              child: ElevatedButton(
                onPressed: _loading ? null : _simpan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                ),
                child: _loading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : Text(_isEdit ? 'SIMPAN PERUBAHAN' : 'TAMBAH'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl,
      {TextInputType? keyboard, bool required = true}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: ctrl,
        keyboardType: keyboard,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        validator: required
            ? (v) => (v == null || v.isEmpty) ? '$label wajib diisi' : null
            : null,
      ),
    );
  }
}